import java.io.*;
import java.util.*;

import org.omg.PortableServer.ImplicitActivationPolicyOperations;
public class Touch {
	 enum Action {
		 ACTION_DOWN, // � ������������ �������� � ������ ������ ����� � �������� �����. 
		 ACTION_POINTER_DOWN, // � ������������ �������� � ������ ������ ����� � �������� �����. 
		 ACTION_MOVE, // � ������������ ���������� ����� � �������� �����. 
		 ACTION_POINTER_UP, // � ������������ ���������� ������ ����� � �������� ����� � �������� ���. 
		 ACTION_UP, // � ������������ ���������� ������ ����� � �������� ����� � �������� ���. 
		 ACTION_CANCEL // � ������������ ������� ����. 
	}
	public static class MotionEvent {
		private float _x;
		private float _y;
		private Action _eventId;
		private int _pointerId;
		
		public MotionEvent(float x, float y, int pointerId, Action eventId) {
			_x = x;
			_y = y;
			_pointerId = pointerId;
			_eventId = eventId;
		}

		public Action getEventId() {
			return _eventId;
		}

		public float getY() {
			return _y;
		}

		public float getX() {
			return _x;
		}

		public int getPointerId() {
			return _pointerId;
		}
	}
	
	//https://stackoverflow.com/a/18276033
	public class RotationGestureDetector {
		private static final int INVALID_POINTER_ID = -1;
		private float fX, fY, sX, sY;
		private int ptrID1, ptrID2;
		private float mAngle;
		private float cumAngle = 0;

		//private OnRotationGestureListener mListener;
		private HashMap<Integer, MotionEvent> events = new HashMap<>();

		public float getAngle() {
			return cumAngle;
		}

		public RotationGestureDetector(/*OnRotationGestureListener listener*/) {
			//mListener = listener;
			ptrID1 = INVALID_POINTER_ID;
			ptrID2 = INVALID_POINTER_ID;
		}

		public boolean onTouchEvent(MotionEvent event) {
			events.put(event.getPointerId(), event);
			switch (event.getEventId()/*event.getActionMasked()*/) {
			case ACTION_DOWN:
				ptrID1 = event.getPointerId();

				sX = event.getX();
				sY = event.getY();
				break;
			case ACTION_POINTER_DOWN:
				ptrID2 = event.getPointerId();

				fX = event.getX();
				fY = event.getY();
				break;
			case ACTION_MOVE:
				if (ptrID1 != INVALID_POINTER_ID && ptrID2 != INVALID_POINTER_ID) {
					updateAngle();

					/*if (mListener != null) {
						mListener.OnRotation(this);
					}*/
				}
				break;
			case ACTION_UP:
				// coordinates of UP may differ from ACTION_MOVE last coordinates,
				// we need update angle too
				if (ptrID1 != INVALID_POINTER_ID && ptrID2 != INVALID_POINTER_ID) {
					updateAngle();
					cumAngle += mAngle;
				}
				events.remove(ptrID1);
				ptrID1 = INVALID_POINTER_ID;
				break;
			case ACTION_POINTER_UP:
				if (ptrID1 != INVALID_POINTER_ID && ptrID2 != INVALID_POINTER_ID) {
					updateAngle();
					cumAngle += mAngle;
				}
				events.remove(ptrID2);
				ptrID2 = INVALID_POINTER_ID;
				break;
			case ACTION_CANCEL:
				events.remove(ptrID1);
				events.remove(ptrID2);
				ptrID1 = INVALID_POINTER_ID;
				ptrID2 = INVALID_POINTER_ID;
				break;
			}
			return true;
		}

		private float angleBetweenLines(float fX, float fY, float sX, float sY, float nfX, float nfY, float nsX,
				float nsY) {
			float angle1 = (float) Math.atan2((fY - sY), (fX - sX));
			float angle2 = (float) Math.atan2((nfY - nsY), (nfX - nsX));

			float angle = angle2 - angle1;//angle1 - angle2;
			/*if (angle < -180.f)
				angle += 360.0f;
			if (angle > 180.f)
				angle -= 360.0f;*/
			return angle;
		}

		private void updateAngle() {
			float nfX, nfY, nsX, nsY;
			nsX = events.get(ptrID1).getX();//event.getX(event.findPointerIndex(ptrID1));
			nsY = events.get(ptrID1).getY();//event.getY(event.findPointerIndex(ptrID1));
			nfX = events.get(ptrID2).getX();//event.getX(event.findPointerIndex(ptrID2));
			nfY = events.get(ptrID2).getY();//event.getY(event.findPointerIndex(ptrID2));

			mAngle = angleBetweenLines(fX, fY, sX, sY, nfX, nfY, nsX, nsY);
			/*out.println(String.format("pointer between (%f,%f)->(%f,%f) and (%f,%f)->(%f,%f)", sX, sY, fX, fY, nsX, nsY,
					nfX, nfY));
			out.println("angle = " + mAngle);*/
		}
		/*public static interface OnRotationGestureListener {
			public void OnRotation(RotationGestureDetector rotationDetector);
		}*/
	}
	
	public class ScaleGestureListener {
		private static final int INVALID_POINTER_ID = -1;
		private float fX, fY, sX, sY;
		private int ptrID1, ptrID2;
		private float mScale;
		private float cumScale = 1.0f;

		//private OnRotationGestureListener mListener;
		private HashMap<Integer, MotionEvent> events = new HashMap<>();

		public float getScale() {
			return cumScale;
		}

		public ScaleGestureListener(/*OnRotationGestureListener listener*/) {
			//mListener = listener;
			ptrID1 = INVALID_POINTER_ID;
			ptrID2 = INVALID_POINTER_ID;
		}

		public boolean onTouchEvent(MotionEvent event) {
			events.put(event.getPointerId(), event);
			switch (event.getEventId()/*event.getActionMasked()*/) {
			case ACTION_DOWN:
				ptrID1 = event.getPointerId();

				sX = event.getX();
				sY = event.getY();
				break;
			case ACTION_POINTER_DOWN:
				ptrID2 = event.getPointerId();

				fX = event.getX();
				fY = event.getY();
				break;
			case ACTION_MOVE:
				if (ptrID1 != INVALID_POINTER_ID && ptrID2 != INVALID_POINTER_ID) {
					updateScale();

					/*if (mListener != null) {
						mListener.OnRotation(this);
					}*/
				}
				break;
			case ACTION_UP:
				// coordinates of UP may differ from ACTION_MOVE last coordinates,
				// we need update angle too
				if (ptrID1 != INVALID_POINTER_ID && ptrID2 != INVALID_POINTER_ID) {
					updateScale();
					cumScale *= mScale;
				}
				events.remove(ptrID1);
				ptrID1 = INVALID_POINTER_ID;
				break;
			case ACTION_POINTER_UP:
				if (ptrID1 != INVALID_POINTER_ID && ptrID2 != INVALID_POINTER_ID) {
					updateScale();
					cumScale *= mScale;
				}
				events.remove(ptrID2);
				ptrID2 = INVALID_POINTER_ID;
				break;
			case ACTION_CANCEL:
				events.remove(ptrID1);
				events.remove(ptrID2);
				ptrID1 = INVALID_POINTER_ID;
				ptrID2 = INVALID_POINTER_ID;
				break;
			}
			return true;
		}

		private float scaleChange(float fX, float fY, float sX, float sY, float nfX, float nfY, float nsX,
				float nsY) {
			float length1 = (float) Math.sqrt(Math.pow(fX-sX, 2) + Math.pow(fY-sY, 2));
			float length2 = (float) Math.sqrt(Math.pow(nfX-nsX, 2) + Math.pow(nfY-nsY, 2));
			return length2 / length1;
			
		}

		private void updateScale() {
			float nfX, nfY, nsX, nsY;
			nsX = events.get(ptrID1).getX();//event.getX(event.findPointerIndex(ptrID1));
			nsY = events.get(ptrID1).getY();//event.getY(event.findPointerIndex(ptrID1));
			nfX = events.get(ptrID2).getX();//event.getX(event.findPointerIndex(ptrID2));
			nfY = events.get(ptrID2).getY();//event.getY(event.findPointerIndex(ptrID2));

			mScale = scaleChange(fX, fY, sX, sY, nfX, nfY, nsX, nsY);
			/*out.println(String.format("pointer between (%f,%f)->(%f,%f) and (%f,%f)->(%f,%f)", sX, sY, fX, fY, nsX, nsY,
					nfX, nfY));
			out.println("scale = " + mScale);*/
		}
		/*public static interface OnRotationGestureListener {
			public void OnRotation(RotationGestureDetector rotationDetector);
		}*/
	}
	
	static class Algo {
		
		/***
		 * 
		 * @param vectorX
		 * @param vectorY
		 * @param radians
		 * @return float[2] array of new vector coordinates
		 */
		static float[] rotateVector(float vectorX, float vectorY, double radians) {
			double cosAlpha = Math.cos(radians);
			double sinAlpha = Math.sin(radians);
			return new float[] { (float) (cosAlpha * vectorX - sinAlpha * vectorY),
					(float) (sinAlpha * vectorX + cosAlpha * vectorY) };
		}
	}
		
	public static void main(String[] args) throws IOException {
		new Touch().run();
	}

	//private StreamTokenizer in;
	private BufferedReader reader;
	private PrintWriter out;


	void run() throws IOException {
		reader = new BufferedReader(new FileReader("input.txt"));
		out = new PrintWriter(System.out);
		solve();
		out.flush();
	}

	void solve() throws IOException {
		float circleX,circleY,circleRadius;
		float rotationX, rotationY;
		
		String line = reader.readLine();
		String[] words = line.split(" ");
		circleX = Float.valueOf(words[0]);
		circleY = Float.valueOf(words[1]);
		circleRadius = Float.valueOf(words[2]);
		
		line = reader.readLine();
		words = line.split(" ");
		rotationX = Float.valueOf(words[0]);
		rotationY = Float.valueOf(words[1]);
		
		RotationGestureDetector rotation = new RotationGestureDetector();
		ScaleGestureListener scale = new ScaleGestureListener();
		while ((line = reader.readLine()) != null) {
			words = line.split(" ");
			int pointerId = Integer.valueOf(words[0]);
			float x = Float.valueOf(words[1]);
			float y = Float.valueOf(words[2]);
			String actionStr = words[3];
			Action action = Action.valueOf(actionStr);
			//out.println(pointerId + " " + x + " " + y + " " + action);
			MotionEvent event = new MotionEvent(x, y, pointerId, action);
			rotation.onTouchEvent(event);
			scale.onTouchEvent(event);
		}
		
		//out.println(rotation.getAngle());
		float[] rotatedVector = Algo.rotateVector(
				circleX - rotationX, circleY - rotationY, rotation.getAngle());
		float xNew = rotationX + rotatedVector[0];
		float yNew = rotationY + rotatedVector[1];
		float radius = circleRadius * scale.getScale();
		//out.println(xNew + " " + yNew + " " + radius);
		
		out.println(Math.round(xNew) + " " + Math.round(yNew) + " " + Math.round(radius));
	}
}