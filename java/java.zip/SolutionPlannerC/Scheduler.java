import java.io.*;
import java.util.*;

public class Scheduler {
	private StreamTokenizer in;
	private PrintWriter out;
	
	int nextInt() throws IOException {
		in.nextToken();
		return (int) in.nval;
	}
	
	public static void main(String[] args) throws IOException {
		new Scheduler().process();
	}

	void process() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		solve();
		out.flush();
	}

	ArrayList<Integer> time = new ArrayList<>();
	ArrayList<Integer> limit = new ArrayList<>();
	
	class Thread {
		int busyTill = 0;
		int id = 0;
		public Thread(int _id) {
			id = _id;
		}
	}
	
	ArrayList<Thread> threads = new ArrayList<>();
	private int n;
	
	void solve() throws IOException {
		double energy = 0;
		
		// read
		n = nextInt();
		for (int index = 0; index < n; index++) {
			time.add(nextInt());
			limit.add(nextInt());
			
			plan(time.get(index), limit.get(index));
		}
		
		for (int index = 0; index < threads.size(); index++) {
			energy += threads.get(index).busyTill * Math.pow(1.5, threads.get(index).id);
		}
		out.println(energy);
	}
	
	void plan(int time, int limit) {
		for (Thread thread : threads) {
			int space = Math.max(limit - thread.busyTill, 0);
			int giveTime = Math.min(space, time);
			time -= giveTime;
			thread.busyTill += giveTime;
		}
		
		// add new threads for help
		while (time > 0) {
			Thread newThread = new Thread(threads.size());
			int space = limit - newThread.busyTill;
			int giveTime = Math.min(space, time);
			time -= giveTime;
			newThread.busyTill += giveTime;
			threads.add(newThread);
		}
	}
}