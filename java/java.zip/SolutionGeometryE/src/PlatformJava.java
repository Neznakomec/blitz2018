import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

import static java.lang.Math.PI;
public class PlatformJava {
	private static final int N = 7;

    public static class Point {
        public final Double x;
        public final Double y;

        public Point(Double x, Double y) {
            this.x = x;
            this.y = y;
        }
    }

    public static class Size {
        public final Double width;
        public final Double height;

        public Size(Double width, Double height) {
            this.width = width;
            this.height = height;
        }
    }

    public static class Rect {
        public final Point point;
        public final Size size;

        public Rect(Point point, Size size) {
            this.point = point;
            this.size = size;
        }
    }

	public static class Algo {
		
		// from https://www.geeksforgeeks.org/program-for-point-of-intersection-of-two-lines/
		static Point lineLineIntersection(Point A, Point B, Point C, Point D) {
			// Line AB represented as a1x + b1y = c1
			double a1 = B.y - A.y;
			double b1 = A.x - B.x;
			double c1 = a1 * (A.x) + b1 * (A.y);

			// Line CD represented as a2x + b2y = c2
			double a2 = D.y - C.y;
			double b2 = C.x - D.x;
			double c2 = a2 * (C.x) + b2 * (C.y);

			double determinant = a1 * b2 - a2 * b1;

			if (determinant == 0) {
				// The lines are parallel. This is simplified
				// by returning a pair of FLT_MAX
				return new Point(Double.MAX_VALUE, Double.MAX_VALUE);
			} else {
				double x = (b2 * c1 - b1 * c2) / determinant;
				double y = (a1 * c2 - a2 * c1) / determinant;
				return new Point(x, y);
			}
		}
	}
    
    public static Rect readInputRect() throws IOException {
        String input = readFile("input.txt", StandardCharsets.UTF_8);
        Double[] data = Arrays.stream(input.split("\\s"))
          .map(Double::parseDouble).toArray(Double[]::new);
        return new Rect(new Point(data[0], data[1]),
                        new Size(data[2], data[3]));
    }

    public static void writeResult(Point[] points) throws IOException {
        List<String> outputData = Arrays.stream(points)
          .map(p -> new Integer[] { (int) Math.round(p.x), (int) Math.round(p.y) })
          .map(pts -> String.format(Locale.US, "%1$d %2$d", pts[0], pts[1]))
          .collect(Collectors.toList());

        String result = String.join(" ", outputData);
        Files.write(Paths.get("output.txt"),
                    Collections.singletonList(result),
                    StandardCharsets.UTF_8);
    }

    private static String readFile(String path, Charset encoding)
            throws IOException {
        byte[] encoded = Files.readAllBytes(Paths.get(path));
        return new String(encoded, encoding);
    }
    
    public static void main(String[] args) throws IOException {
		Rect rectangle = readInputRect();
		
		Point[] polygon = new Point[N];
		Point[] midPoints = new Point[N];
		
		if (rectangle.size.width <= 0 || rectangle.size.height <= 0) {
			return;
		}
		double radius = circleRadius(rectangle);
		
		//test();
		double phi = - PI / 2; //0;
		for (int i = 0; i < N; i++) {
			double xi = radius * Math.cos(phi + 2 * PI * i / N);
			double yi = radius * Math.sin(phi + 2 * PI * i / N);
			polygon[i] = new Point(xi, yi);
		}
		
		Point translate = getTranslate(rectangle, polygon);
		for (int i = 0; i < N; i++) {
			polygon[i] = new Point(polygon[i].x + translate.x,
					polygon[i].y + translate.y);
		}

		for (int i = 0; i < N; i++) {
			int p1i = i;
			int p2i = i+2;
			int p3i = i-1;
			int p4i = i+1;
			Point l1p1 = polygon[(p1i + N) % N];
			Point l1p2 = polygon[(p2i + N) % N];
			Point l2p1 = polygon[(p3i + N) % N];
			Point l2p2 = polygon[(p4i + N) % N];
			
			Point point = Algo.lineLineIntersection(l1p1, l1p2, l2p1, l2p2);
			midPoints[i] = point;
		}
		
		ArrayList<Point> points = new ArrayList<Point>();
		for (int index = 0; index < N; index++) {
			points.add(polygon[index]);
			points.add(midPoints[index]);
		}
		
		writeResult(points.toArray(new Point[points.size()]));
	}
    
    private static Double circleRadius(Rect rectangle) {
    	double minSideSize = Math.min(rectangle.size.width, rectangle.size.height);
    	int i = 2, j = 5; // right and left
        int k = 3; // lowest
    	double radius1 = rectangle.size.width / 
    			(-Math.cos(-PI/2 - 2 * PI * i / N) + Math.cos(-PI/2 - 2 * PI * j / N));
        double radius2 = minSideSize / (1 + Math.sin(-PI/2 - 2 * PI * k / N));

        return Math.min(radius1, radius2);
    }
    
    private static Point getTranslate(Rect rectangle, Point[] polygon) {
    	double xmin = polygon[0].x;
    	double ymin = polygon[0].y;
    	double xmax = polygon[0].x;
    	double ymax = polygon[0].y;
    	
    	for (int point = 0; point < polygon.length; point++) {
    		xmin = Math.min(xmin, polygon[point].x);
    		xmax = Math.max(xmax, polygon[point].x);
    		ymin = Math.min(ymin, polygon[point].y);
    		ymax = Math.max(ymax, polygon[point].y);
    	}
    	
    	double size = Math.min(rectangle.size.width, rectangle.size.height);
    	
    	double xdiff = (rectangle.point.x - xmin);
    	if (rectangle.size.width > rectangle.size.height) {
    			xdiff += (rectangle.size.width - (xmax-xmin)) / 2;
    	} else {
    		xdiff += (size - (xmax-xmin)) / 2;
    	}
    	double ydiff = (rectangle.point.y - ymin);
    	if (rectangle.size.height > rectangle.size.width) {
    			ydiff += (rectangle.size.height - (ymax-ymin)) / 2;
    	} else {
    		ydiff += (size - (ymax-ymin)) / 2;
    	}
    	return new Point(xdiff, ydiff);
    }
    
	public void test() {
    	double R = 1;
    	double X = 0, Y = 0;
    	Point[] polygon = new Point[N];
		Point[] midPoints = new Point[N];
    	
		double phi = - PI / 2; //0;
		for (int i = 0; i < N; i++) {
			double xi = X + R * Math.cos(phi + 2 * PI * i / N);
			double yi = Y + R * Math.sin(phi + 2 * PI * i / N);
			polygon[i] = new Point(xi, yi);
		}
		
		for (int i = 0; i < N; i++) {
			int p1i = i;
			int p2i = i+2;
			int p3i = i-1;
			int p4i = i+1;
			Point l1p1 = polygon[(p1i + N) % 7];
			Point l1p2 = polygon[(p2i + N) % 7];
			Point l2p1 = polygon[(p3i + N) % 7];
			Point l2p2 = polygon[(p4i + N) % 7];
			
			Point point = Algo.lineLineIntersection(l1p1, l1p2, l2p1, l2p2);
			midPoints[i] = point;
		}
		
		for (int i = 0; i < N; i++) {
			System.out.println(polygon[i].x + polygon[i].y);
			System.out.println(midPoints[i].x + midPoints[i].y);
		}
    }
}