import java.io.*;
import java.util.*;

public class DragonKiller {
	private StreamTokenizer in;
	private PrintWriter out;
	
	int nextInt() throws IOException {
		in.nextToken();
		return (int) in.nval;
	}
	
	private static class Dragon {
		int PhysicalPower;
		int MagPower;
		int Experience;
		public Dragon(int mag, int phys, int exp) {
			MagPower = mag;
			PhysicalPower = phys;
			Experience = exp;
		}
	}
	
	private static class Drink {
		int weight;
		int power;
		public Drink(int power, int weight) {
			this.weight = weight;
			this.power = power;
		}
	}
	public static void main(String[] args) throws IOException {
		new DragonKiller().process();
	}

	void process() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		solve();
		out.flush();
	}

	private int  maxPhys, maxMag, maxWeightK, dragonsN, drinksM;
	private ArrayList<Dragon> dragons = new ArrayList<>();
	private ArrayList<Drink> drinks = new ArrayList<>();





	void solve() throws IOException {
		// read
		maxWeightK = nextInt();
		maxPhys = nextInt();
		dragonsN = nextInt();
		
		dragons.ensureCapacity(dragonsN);
		for (int index = 0; index < dragonsN; index++) {
			Dragon dragon = new Dragon(nextInt(), nextInt(), nextInt());
			dragons.add(dragon);
		}
		
		drinksM = nextInt();
		drinks.ensureCapacity(drinksM);
		for (int index = 0; index < drinksM; index++) {
			Drink drink = new Drink(nextInt(), nextInt());
			drinks.add(drink);
		}
		
		//calculate mag power in backpack
		maxMag = 0;
		int drinkLimit = 1 << drinks.size();
		for (int drinkMask = 0; drinkMask < drinkLimit; drinkMask++) {
			int power = 0;
			int weight = 0;
			for (int bit = 0; bit < drinks.size(); bit++) {
				if ((drinkMask >> bit & 1) == 1) {
					Drink drink = drinks.get(bit);
					power += drink.power;
					weight += drink.weight;
				}
			}

			if (weight <= maxWeightK) {
				if (power > maxMag) {
					maxMag = power;
				}
			} else {
				continue;
			}
		}
		
		//calculate
		int dragonsLimit = 1 << dragons.size();
		int maxExp = 0;
		for (int dragonMask = 0; dragonMask < dragonsLimit; dragonMask++) {
			int mag = maxMag;
			int phys = maxPhys;
			int exp = 0;
			for (int bit = 0; bit < dragons.size(); bit++) {
				if ((dragonMask >> bit & 1) == 1) {
					Dragon dragon = dragons.get(bit);
					mag -= dragon.MagPower;
					phys -= dragon.PhysicalPower;
					exp += dragon.Experience;
				}
			}

			if (mag >= 0 && phys >= 0) {
				if (exp > maxExp) {
					maxExp = exp;
				}
			} else {
				continue;
			}
		} 
		
		out.println(maxExp);
	}
}