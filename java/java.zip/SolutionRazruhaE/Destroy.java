import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Destroy {
	private StreamTokenizer in;
	private PrintWriter out;
	
	int nextInt() throws IOException {
		in.nextToken();
		return (int) in.nval;
	}
	
	double nextDouble() throws IOException {
		in.nextToken();
		return in.nval;
	}
	
	public static void main(String[] args) throws IOException {
		new Destroy().process();
	}

    public static class Point {
        public final Double x;
        public final Double y;

        public Point(Double x, Double y) {
            this.x = x;
            this.y = y;
        }
        
        @Override
        public String toString() {
        	return String.format("(x=%f;y=%f)", x,y);
        }
    }
    
	void process() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		solve();
		out.flush();
	}

	private int n;
	private ArrayList<Point> points = new ArrayList<>();
	
	void solve() throws IOException {
		// read
		n = nextInt();
		for (int index = 0; index < n; index++) {
			points.add(new Point(nextDouble(), nextDouble()));
		}
		
		double length = split(points);
		String str = String.format("%.6f", length);
		str = str.replace(',', '.');
		out.print(str);
	}
	
	private double split(ArrayList<Point> polygon) {
		if (polygon.size() <= 3) {
			return 0.0;
		}
		
		int N = polygon.size();
		Point prev, curr, next;
		int index = 0;
		// check clockwise
		//https://stackoverflow.com/questions/1165647/how-to-determine-if-a-list-of-polygon-points-are-in-clockwise-order
		double area = 0;
		for (index = 0; index < N; index++) {
			curr = polygon.get(index);
			next = polygon.get((index+1 + N) % N);
			area += (curr.x+next.x)*(next.y-curr.y);
		}
		
		double clockWiseRotation = Math.signum(area); 

		
		// find problem
		double length = 0;
		for (index = 0; index < N; index ++) {
			curr = polygon.get(index);
			prev = polygon.get((index-1 + N) % N);
			next = polygon.get((index+1 + N) % N);
			double povorot = povorot3Points(prev, curr, next);
			if (povorot != 0 && povorot!= clockWiseRotation) {
				int badPoint = index;
				double minDist = Double.MAX_VALUE;
				int minIndex = 0;
				for (int idx = 0; idx <= badPoint - 2; idx++ ) {
					Point point = polygon.get(idx);
					if (povorot3Points(prev, curr, point) == clockWiseRotation && distBetween(curr, point) < minDist) {
						minDist = distBetween(curr, point);
						minIndex = idx;
					}
				}
				
				for (int idx = badPoint + 2; idx < N; idx++ ) {
					Point point = polygon.get(idx);
					if (povorot3Points(prev, curr, point) == clockWiseRotation && distBetween(curr, point) < minDist) {
						minDist = distBetween(curr, point);
						minIndex = idx;
					}
				}
				
				length = distBetween(polygon.get(badPoint), polygon.get(minIndex));
				//out.println("bad point " + badPoint + " tofix = " + minIndex + " length = " + length);
				ArrayList<Point> poly1 = new ArrayList<>();
				for (int i = 0; i <= Math.min(minIndex, badPoint); i++) {
					//out.println("poly1 add point " + i);
					poly1.add(polygon.get(i));
				}
				for (int i = Math.max(minIndex, badPoint); i < N; i++) {
					//out.println("poly1 add point " + i);
					poly1.add(polygon.get(i));
				}
				
				ArrayList<Point> poly2 = new ArrayList<>();
				for (int i = Math.min(minIndex, badPoint); i <= Math.max(minIndex, badPoint); i++) {
					//out.println("poly2 add point " + i);
					poly2.add(polygon.get(i));
				}
				
				length += split(poly1);
				

				length += split(poly2);
				break;
			}
		}
		return length;
	}
	
	double povorot3Points(Point prev, Point curr, Point next) {
		// https://ru.stackoverflow.com/questions/745141/Определение-выпуклости-многоугольника
		Point ab = new Point(
			  curr.x - prev.x, 
			  curr.y - prev.y
			);
		
		Point bc = new Point(
			 next.x - curr.x, 
			 next.y - curr.y
			 );

		double product = Math.signum(ab.x * bc.y - ab.y * bc.x);
		
		return product;
	}
	
	double distBetween(Point prev, Point curr) {
		return Math.sqrt(Math.pow((prev.x-curr.x), 2.0d) + 
				Math.pow((prev.y - curr.y), 2.0d));
	}
	     
}