import java.io.*;
import java.util.*;

public class SolutionBashni {
	private static final int NMAX = 50;
	private final int[] grandi = new int[NMAX+1];
	
	public static void main(String[] args) throws IOException {
		new SolutionBashni().run();
	}

	private StreamTokenizer in;
	private PrintWriter out;

	int nextInt() throws IOException {
		in.nextToken();
		return (int) in.nval;
	}

	void run() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		solve();
		out.flush();
	}

	void solve() throws IOException {
	    calculateGrandiNumbers(NMAX);

	    int countGames = nextInt();
		for (int game = 0; game < countGames; game++) {
			int countTowers = nextInt();
			int G = 0;
			for (int tower = 0; tower < countTowers; tower++) {
				int height = nextInt();
				G = G ^ grandi[height];
			}
			
			String loser = "";
			if (G == 0) {
				loser = "Человек";
			} else {
				loser = "Робот";
			}
			
			out.println(loser);
		}

	}

	public interface IPartitionHandler<T> {
		void handle(List<T> partition, int size);
	}
	
	public class PrintPartitions implements IPartitionHandler<Integer> {

		@Override
		public void handle(List<Integer> partition, int size) {
			for (int i=0; i < size; i++) {
				System.out.print(partition.get(i) + " ");
			}
			System.out.println();
		}
	}
	
	public class GameStateGrandiCalculator implements IPartitionHandler<Integer> {
		private Set<Integer> correspondingGrandiNumbers = new HashSet<Integer>();

		@Override
		public void handle(List<Integer> partition, int size) {
			int g = 0;
			for (int index = 0; index < size; index++) {
				g = g ^ grandi[partition.get(index)];
			}
			
			correspondingGrandiNumbers.add(g);
		}
		
		private int mex(Set<Integer> set) {
			int number = 0;
			while (set.contains(number)) {
				number++;
			}
			
			return number;
		}
		
		public int getStateGrandiNumber() {
			return mex(correspondingGrandiNumbers);
		}
	}
	
    private class DistinctPartitions {
    	private int number;
    	private IPartitionHandler<Integer> handler;
    	private List<Integer> partitionCache;
    	public DistinctPartitions(int number, IPartitionHandler<Integer> handler) {
    		this.number = number;
    		this.handler = handler;
    	}
    	
    	public void runEnumeration() {
    		partitionCache = new ArrayList<Integer>(Collections.nCopies(number / 2 + 1, 0));
    	    for(int i = 1; i < number; i++)
    	    {
    	        partitionCache.set(0, i);
    	        partitions(number, 0, partitionCache, 0);
    	    }
    	}
    	
    	//https://www.oipapio.com/question-4308416
    	private void partitions(int target, int curr, List<Integer> array, int idx)
    	{
    	    if (curr + array.get(idx) == target)
    	    {
    	    	handler.handle(array, idx + 1);
    	        return;
    	    }
    	    else if (curr + array.get(idx) > target)
    	    {
    	        return;
    	    }
    	    else
    	    {
    	        for(int i = array.get(idx)+1; i < target; i++)
    	        {
    	        	array.set(idx+1, i);
    	            partitions(target, curr + array.get(idx), array, idx+1);
    	        }
    	    }
    	}
    	
    }
	private void calculateGrandiNumbers(int nmax) {
		if (nmax >= 2) {
			grandi[1] = 0;
			grandi[2] = 0;
		}
		
		for (int size = 3; size <= nmax; size++) {
			GameStateGrandiCalculator grandiFunctionValue =
					new GameStateGrandiCalculator();
			new DistinctPartitions(size, grandiFunctionValue).runEnumeration();
			grandi[size] = grandiFunctionValue.getStateGrandiNumber();
		}
	}
}