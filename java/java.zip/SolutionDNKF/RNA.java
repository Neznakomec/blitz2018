import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RNA {
	private StreamTokenizer in;
	private PrintWriter out;
	
	int nextInt() throws IOException {
		in.nextToken();
		return (int) in.nval;
	}
	
	String nextString() throws IOException {
		in.nextToken();
		return in.sval;
	}
	
	public static void main(String[] args) throws IOException {
		new RNA().process();
	}

	void process() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		solve();
		out.flush();
	}

	ArrayList<String> searches = new ArrayList<>();
	TreeMap<Integer, String> foundSeqs = new TreeMap<>();
	private int n;
	
	void solve() throws IOException {
		// read
		n = nextInt();
		for (int index = 0; index < n; index++) {
			searches.add(nextString());
		}
		
		String dnk = nextString();
		for (int index = 0; index < n; index++) {
			String sequence = searches.get(index);
			
			Pattern p = Pattern.compile(sequence);  
			Matcher m = p.matcher(dnk);
			int searchIndex = 0;
			while(m.find(searchIndex)) {
		    	 foundSeqs.put(m.start() + 1, sequence);
		    	 searchIndex = m.start() + 1;
		     }
		}
		
		for(Map.Entry<Integer,String> entry : foundSeqs.entrySet()) {
			Integer key = entry.getKey();
			  String value = entry.getValue();

			  out.println(key + " " + value);
			   
			}
	}
	     
}