import java.io.*;
import java.util.*;

public class Factories {
	private StreamTokenizer in;
	private PrintWriter out;
	
	int nextInt() throws IOException {
		in.nextToken();
		return (int) in.nval;
	}
	
	private static class Energy {
		private int _cost;
		private int _energy;
		
		public int getCost() {
			return _cost;
		}
		
		public int getEnergy() {
			return _energy;
		}
		
		public Energy setCost(int cost) {
			_cost = cost;
			return this;
		}
		public Energy setEnergy(int energy) {
			_energy = energy;
			return this;
		}
	}
	
	private static class Coal {
		private int _cost;
		private int _energy;
		private int _coal;
		
		public int getCost() {
			return _cost;
		}
		
		public int getEnergy() {
			return _energy;
		}
		
		public int getCoal() {
			return _coal;
		}
		
		public Coal setCost(int cost) {
			_cost = cost;
			return this;
		}
		public Coal setEnergy(int energy) {
			_energy = energy;
			return this;
		}
		
		public Coal setCoal(int coal) {
			_coal = coal;
			return this;
		}

	}
	public static void main(String[] args) throws IOException {
		new Factories().process();
	}

	void process() throws IOException {
		in = new StreamTokenizer(new BufferedReader(new FileReader("input.txt")));
		out = new PrintWriter(new FileWriter("output.txt"));
		solve();
		out.flush();
	}

	private int balance;
	private ArrayList<Energy> energies = new ArrayList<>();
	private ArrayList<Coal> coalFactories = new ArrayList<>();





	void solve() throws IOException {
		// read
		balance = nextInt();
		
		int nEnergy = nextInt();
		energies.ensureCapacity(nEnergy);
		for (int index = 0; index < nEnergy; index++) {
			Energy energy = new Energy()
					.setCost(nextInt()).setEnergy(nextInt());
			energies.add(energy);
		}
		
		int nPlants = nextInt();
		coalFactories.ensureCapacity(nPlants);
		for (int index = 0; index < nPlants; index++) {
			Coal plant = new Coal()
					.setCost(nextInt()).setEnergy(nextInt()).setCoal(nextInt());
			coalFactories.add(plant);
		}
		
		//calculate
		long energyVariantsLimit = 1 << energies.size();
		long coalVariantsLimit = 1 << coalFactories.size();
		
		int maxCoal = 0;
		class State {
			final int money;
			int moneySpent;
			int energyReceived;
			int coalProduced;
			
			public State(int money) {
				this.money = money;
			}
			void reset() {
				moneySpent = energyReceived = coalProduced = 0;
			}
			
			boolean check() {
				return moneySpent <= money && energyReceived >= 0;
			}
			
			void copyTo(State other) {
				other.coalProduced = coalProduced;
				other.energyReceived = energyReceived;
				other.moneySpent = moneySpent;
			}
		};
		State state = new State(balance);
		State intermediateResult = new State(balance);
		
		for (long energyMask = 0; energyMask < energyVariantsLimit; energyMask++) {
			state.reset();
			
			for (int bit = 0; bit < energies.size(); bit++) {
				if ((energyMask >> bit & 1) == 1) {
					Energy energy = energies.get(bit);
					state.moneySpent += energy.getCost();
					state.energyReceived += energy.getEnergy();
				}
			}
			
			if (state.moneySpent > balance) {
				// incorrect case
				continue;
			}
			
			state.copyTo(intermediateResult);
			for (long coalMask = 0; coalMask < coalVariantsLimit; coalMask++) {
				intermediateResult.copyTo(state);
				for (int bit = 0; bit < coalFactories.size(); bit++) {
					if ((coalMask >> bit & 1) == 1) {
						Coal coal = coalFactories.get(bit);
						state.moneySpent += coal.getCost();
						state.energyReceived -= coal.getEnergy();
						state.coalProduced += coal.getCoal();
					}
				}

				if (state.coalProduced > maxCoal && state.check()) {
					maxCoal = state.coalProduced;
				}
			}
		}
		
		out.println(maxCoal);
	}
}