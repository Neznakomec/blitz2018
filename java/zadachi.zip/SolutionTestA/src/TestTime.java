import java.io.*;
import java.util.*;

public class TestTime {
	private static final boolean FILE_INPUT_OUTPUT = true;

	// TODO: implement reader/writer class(classes)
	private static StreamTokenizer in;
	private static ArrayList<Integer> testTimes = new ArrayList<>();
	private static int devices;

	public static void main(String[] args) throws IOException {
		Reader reader = FILE_INPUT_OUTPUT ? new FileReader("input.txt") : new InputStreamReader(System.in);
		Writer writer = FILE_INPUT_OUTPUT ? new PrintWriter("output.txt") : new OutputStreamWriter(System.out);
		in = new StreamTokenizer(reader);

		readData(reader);
		new TestTimeCalculator(devices, testTimes).solve().writeAnswer(writer);
	}

	private static void readData(Reader reader) throws IOException {
		int taskCount = nextInt();
		devices = nextInt();

		for (int task = 0; task < taskCount; task++) {
			int time = nextInt();
			testTimes.add(time);
		}
	}

	private static int nextInt() throws IOException {
		in.nextToken();
		return (int) in.nval;
	}

	private static class TestTimeCalculator {
		private ArrayList<Integer> mTestTimes;
		private int mDevicesCount;
		private long timeDurationAnswer;

		public TestTimeCalculator(int devices, ArrayList<Integer> testTimes) {
			mTestTimes = testTimes;
			mDevicesCount = devices;
		}

		TestTimeCalculator solve() throws IOException {
			timeDurationAnswer = 0;
			ArrayList<Integer> mTestTime = new ArrayList<>(mTestTimes);
			Collections.sort(mTestTime, Collections.reverseOrder());
			for (int testIndex = 0; testIndex < mTestTimes.size(); testIndex++) {
				long launchNumber = testIndex / mDevicesCount;
				long testTime = (2 * launchNumber + 1) * mTestTime.get(testIndex);
				timeDurationAnswer += testTime;
			}

			return this;
		}

		private void writeAnswer(Writer writer) throws IOException {
			writer.write(String.valueOf(timeDurationAnswer));
			writer.flush();
		}
	}
}